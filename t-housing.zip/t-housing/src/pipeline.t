-- ============================================================================
-- Minimal T Pipeline for Housing Data Analysis
-- ============================================================================

-- Intent: Port legacy Python scripts to reproducible T pipeline
intent {
  goal: "Create reproducible pipeline for housing data analysis"
  assumptions: "Excel file exists at data/vente-maison-2010-2021.xlsx"
  dependencies: ["data/vente-maison-2010-2021.xlsx"]
}

-- Pipeline definition
p = pipeline {
  -- ========================================================================
  -- Node 1: Read and Clean Excel Data (Minimal version)
  -- ========================================================================
  clean_data = pyn(
    command = <{
import pandas as pd

# Read all sheets from Excel file
sheets = list(map(str, range(2010, 2022)))

def read_sheet(sheet):
    skip_rows = 8 if sheet == "2021" else 10
    
    df = pd.read_excel(
        io="data/vente-maison-2010-2021.xlsx",
        sheet_name=sheet,
        skiprows=skip_rows,
        header=1
    ).assign(year=sheet)
    
    return df

# Read and concatenate all sheets
raw_data = pd.concat(list(map(read_sheet, sheets)))

# Clean column names
raw_data.columns = [str(col).lower().replace(" ", "_") for col in raw_data.columns]

# Rename columns
raw_data = raw_data.rename(columns={
    "commune": "locality",
    "nombre_doffres": "n_offers",
    "prix_moyen_annonc_en_€_courant": "average_price_nominal_euros",
    "prix_moyen_annonc_au_m_en_€_courant": "average_price_m2_nominal_euros"
})

# Clean locality names
raw_data['locality'] = raw_data['locality'].str.replace('Luxembourg.*', 'Luxembourg', regex=True)
raw_data['locality'] = raw_data['locality'].str.replace('P.*tange', 'Pétange', regex=True)
raw_data['locality'] = raw_data['locality'].str.strip()

# Filter out non-commune rows and null localities
raw_data = raw_data[~raw_data['locality'].str.contains('nationale|offre|Source', regex=True)]
raw_data = raw_data[raw_data['locality'].notna()]

# Clean price columns - simple approach
for col in ['average_price_nominal_euros', 'average_price_m2_nominal_euros']:
    if col in raw_data.columns:
        raw_data[col] = (
            raw_data[col]
            .astype(str)
            .str.replace(' ', '')
            .str.replace('*', '')
            .str.replace(',', '.')
            .astype(float, errors='coerce')
        )

raw_data
    }>,
    serializer = ^arrow
  )
}

-- ============================================================================
-- Pipeline Execution
-- ============================================================================

-- Build the pipeline
res = build_pipeline(p, verbose = 1)

-- Check for errors
if (is_error(res)) {
  print("🚨 Pipeline build failed!")
  print(read_log("clean_data"))
  exit(1)
}

-- Read and display results
print("✅ Pipeline completed successfully!")
final_data = read_node(p.clean_data)
print("Data shape:", nrow(final_data), "rows ×", ncol(final_data), "columns")
print("Column names:", colnames(final_data))
print("Sample data:")
print(head(final_data, 5))

-- Save outputs
write_arrow(final_data, "outputs/cleaned_data.arrow")
write_csv(final_data, "outputs/cleaned_data.csv")
print("📁 Saved outputs to outputs/ directory")