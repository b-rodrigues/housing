p = pipeline {
  read_excel = pyn(
    command = <{
import pandas as pd

# Try reading just one sheet first to debug
sheets = ["2010"]

def read_sheet(sheet):
    skip_rows = 8 if sheet == "2021" else 10
    
    df = pd.read_excel(
        io="data/vente-maison-2010-2021.xlsx",
        sheet_name=sheet,
        skiprows=skip_rows,
        header=1
    ).assign(year=sheet)
    
    return df

raw_data = pd.concat(list(map(read_sheet, sheets)))

# Print some info for debugging
print("Columns:", raw_data.columns.tolist())
print("Column types:", raw_data.dtypes.tolist())
print("First few rows:")
print(raw_data.head())

raw_data
    }>,
    serializer = ^arrow
  )
}

res = build_pipeline(p, verbose = 1)
print("Error in read_excel:")
print(error_msg(p.read_excel))