#!/bin/bash

# Simple data cleaning script
python3 -c "
import pandas as pd

# Read all sheets from Excel file
sheets = list(map(str, range(2010, 2022)))

def read_sheet(sheet):
    skip_rows = 8 if sheet == '2021' else 10
    df = pd.read_excel(
        io='data/vente-maison-2010-2021.xlsx',
        sheet_name=sheet,
        skiprows=skip_rows,
        header=1
    ).assign(year=sheet)
    return df

raw_data = pd.concat(list(map(read_sheet, sheets)))

# Clean column names
raw_data.columns = [str(col).lower().replace(' ', '_') for col in raw_data.columns]

# Rename columns
raw_data = raw_data.rename(columns={
    'commune': 'locality',
    'nombre_doffres': 'n_offers',
    'prix_moyen_annonc_en_€_courant': 'average_price_nominal_euros',
    'prix_moyen_annonc_au_m_en_€_courant': 'average_price_m2_nominal_euros'
})

# Clean locality names
raw_data['locality'] = raw_data['locality'].str.replace('Luxembourg.*', 'Luxembourg', regex=True)
raw_data['locality'] = raw_data['locality'].str.replace('P.*tange', 'Pétange', regex=True)
raw_data['locality'] = raw_data['locality'].str.strip()

# Filter out non-commune rows and null localities
raw_data = raw_data[raw_data['locality'].str.contains('nationale|offre|Source', regex=True) == False]
raw_data = raw_data[raw_data['locality'].notna()]

# Clean price columns
for col in ['average_price_nominal_euros', 'average_price_m2_nominal_euros']:
    if col in raw_data.columns:
        raw_data[col] = raw_data[col].astype(str).str.replace('[^0-9,.]', '', regex=True).str.replace(',', '.').astype(float, errors='coerce')

# Save cleaned data
raw_data.to_csv('outputs/cleaned_data_temp.csv', index=False)
print('Data cleaning completed successfully')
"