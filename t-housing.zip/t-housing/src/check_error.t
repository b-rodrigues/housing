p = pipeline {
  read_excel = pyn(
    command = <{
import pandas as pd
import polars as pl

sheets = list(map(str, range(2010, 2022)))

def read_sheet(sheet):
    skip_rows = 8 if sheet == "2021" else 10
    
    df = pd.read_excel(
        io="data/vente-maison-2010-2021.xlsx",
        sheet_name=sheet,
        skiprows=skip_rows,
        header=1
    ).assign(year=sheet)
    
    return df

raw_data = pd.concat(list(map(read_sheet, sheets)))

# Clean column names first - handle both string and non-string column names
raw_data.columns = [str(col).lower().replace(" ", "_") for col in raw_data.columns]

# Convert to polars
raw_data = pl.from_pandas(raw_data)

raw_data = (
    raw_data
    .rename({
        "commune": "locality",
        "nombre_doffres": "n_offers",
        "prix_moyen_annonc_en_€_courant": "average_price_nominal_euros",
        "prix_moyen_annonc_au_m_en_€_courant": "average_price_m2_nominal_euros"
    })
)

raw_data
    }>,
    serializer = ^arrow
  )
}

res = build_pipeline(p, verbose = 1)
print("Error in read_excel:")
print(error_msg(p.read_excel))
print("\nFull log:")
print(read_log("read_excel"))