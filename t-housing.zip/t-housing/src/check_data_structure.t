p = pipeline {
  read_excel = pyn(
    command = <{
import pandas as pd

sheets = list(map(str, range(2010, 2022)))

def read_sheet(sheet):
    skip_rows = 8 if sheet == "2021" else 10
    
    df = pd.read_excel(
        io="data/vente-maison-2010-2021.xlsx",
        sheet_name=sheet,
        skiprows=skip_rows,
        header=1
    ).assign(year=sheet)
    
    return df

raw_data = pd.concat(list(map(read_sheet, sheets)))

# Clean column names
raw_data.columns = [str(col).lower().replace(" ", "_") for col in raw_data.columns]

print("Type of data:", type(raw_data))
print("Columns:", raw_data.columns.tolist())
print("Sample data:")
print(raw_data.head())

raw_data
    }>,
    serializer = ^csv
  )
}

res = build_pipeline(p, verbose = 1)
print("Build completed")