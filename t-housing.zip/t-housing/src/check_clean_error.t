p = pipeline {
  read_excel = pyn(
    command = <{
import pandas as pd

sheets = list(map(str, range(2010, 2022)))

def read_sheet(sheet):
    skip_rows = 8 if sheet == "2021" else 10
    
    df = pd.read_excel(
        io="data/vente-maison-2010-2021.xlsx",
        sheet_name=sheet,
        skiprows=skip_rows,
        header=1
    ).assign(year=sheet)
    
    return df

raw_data = pd.concat(list(map(read_sheet, sheets)))

# Clean column names
raw_data.columns = [str(col).lower().replace(" ", "_") for col in raw_data.columns]

raw_data
    }>,
    serializer = ^csv
  )

  clean_data = pyn(
    command = <{
import polars as pl
import polars.selectors as cs

# Load data from previous node
df = read_excel

print("Columns in clean_data:", df.columns)
print("Sample data:")
print(df.head())

# Clean price columns - remove special characters and convert to numeric
df = df.with_columns(
    pl.col("prix_moyen_annonc_en_€_courant").str.replace_all(r"[^0-9,.]", "").cast(pl.Float64, strict=False),
    pl.col("prix_moyen_annonc_au_m_en_€_courant").str.replace_all(r"[^0-9,.]", "").cast(pl.Float64, strict=False)
)

df
    }>,
    deserializer = ^csv,
    serializer = ^arrow
  )
}

res = build_pipeline(p, verbose = 1)
print("Error in clean_data:")
print(error_msg(p.clean_data))