-- ============================================================================
-- T Pipeline for Housing Data Analysis
-- ============================================================================

-- Intent: Port legacy Python scripts to reproducible T pipeline
intent {
  goal: "Create reproducible pipeline for housing data analysis"
  assumptions: "Excel file exists at data/vente-maison-2010-2021.xlsx"
  dependencies: ["data/vente-maison-2010-2021.xlsx"]
}

-- Pipeline definition
p = pipeline {
  -- ========================================================================
  -- Node 1: Read Excel Data (Simple version)
  -- ========================================================================
  read_excel = pyn(
    command = <{
import pandas as pd

sheets = list(map(str, range(2010, 2022)))

def read_sheet(sheet):
    skip_rows = 8 if sheet == "2021" else 10
    
    df = pd.read_excel(
        io="data/vente-maison-2010-2021.xlsx",
        sheet_name=sheet,
        skiprows=skip_rows,
        header=1
    ).assign(year=sheet)
    
    return df

raw_data = pd.concat(list(map(read_sheet, sheets)))

# Clean column names
raw_data.columns = [str(col).lower().replace(" ", "_") for col in raw_data.columns]

raw_data
    }>,
    serializer = ^csv
  )

  -- ========================================================================
  -- Node 2: Data Cleaning (Handle all cleaning here)
  -- ========================================================================
  clean_data = pyn(
    command = <{
import pandas as pd
import polars as pl

# Load data from previous node (comes as pandas DataFrame with CSV deserializer)
df = read_excel

# Convert to polars for easier manipulation
df = pl.from_pandas(df)

# Clean price columns - remove special characters and convert to numeric
df = df.with_columns(
    pl.col("prix_moyen_annonc_en_€_courant").str.replace_all(r"[^0-9,.]", "").cast(pl.Float64, strict=False),
    pl.col("prix_moyen_annonc_au_m_en_€_courant").str.replace_all(r"[^0-9,.]", "").cast(pl.Float64, strict=False)
)

df = df.rename({
    "commune": "locality",
    "nombre_doffres": "n_offers",
    "prix_moyen_annonc_en_€_courant": "average_price_nominal_euros",
    "prix_moyen_annonc_au_m_en_€_courant": "average_price_m2_nominal_euros"
})

df = df.with_columns(
    pl.col("locality").str.replace_all("Luxembourg.*", "Luxembourg"),
    pl.col("locality").str.replace_all("P.*tange", "Pétange"),
    pl.col("locality").str.strip_chars()
)

df = df.filter(
    ~pl.col("locality").str.contains("nationale|offre|Source")
)

df = df.filter(pl.col("locality").is_not_null())

df
    }>,
    deserializer = ^csv,
    serializer = ^arrow
  )
}

-- ============================================================================
-- Pipeline Execution
-- ============================================================================

-- Build the pipeline
res = build_pipeline(p, verbose = 1)

-- Check for errors
if (is_error(res)) {
  print("🚨 Pipeline build failed!")
  print(read_log("read_excel"))
  exit(1)
}

-- Read and display results
print("✅ Pipeline completed successfully!")
final_data = read_node(p.clean_data)
print("Data shape:", nrow(final_data), "rows ×", ncol(final_data), "columns")
print("Column names:", colnames(final_data))
print("Sample data:")
print(head(final_data, 5))

-- Save outputs
write_arrow(final_data, "outputs/cleaned_data.arrow")
write_csv(final_data, "outputs/cleaned_data.csv")
print("📁 Saved outputs to outputs/ directory")